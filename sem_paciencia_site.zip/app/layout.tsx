import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "SEM PACIÊNCIA — inglês na prática",
  description: "Pratique inglês com uma professora de IA direta, sarcástica e motivadora."
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}