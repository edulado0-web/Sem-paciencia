 "use client";
import { useState, useRef, useEffect } from "react";

type Msg = { role:"assistant"|"user"; content:string };
const starter:Msg[] = [
 {role:"assistant",content:"E aí. Chega de fugir do inglês. 😒 Vamos começar fácil: tell me your name and one thing you like. Em inglês. Bora."}
];
export default function Home(){
 const [messages,setMessages]=useState<Msg[]>(starter);
 const [input,setInput]=useState("");
 const [busy,setBusy]=useState(false);
 const [level,setLevel]=useState("A1 — começando");
 const [mode,setMode]=useState("Conversação");
 const [notice,setNotice]=useState("");
 const end=useRef<HTMLDivElement>(null);
 useEffect(()=>{end.current?.scrollIntoView({behavior:"smooth"});},[messages]);
 async function send(text=input){
   const clean=text.trim(); if(!clean||busy)return;
   const next=[...messages,{role:"user" as const,content:clean}];
   setMessages(next);setInput("");setBusy(true);setNotice("");
   try{
     const res=await fetch("/api/tutor",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:next,level,mode})});
     const data=await res.json();
     if(!res.ok) throw new Error(data.error||"Não consegui responder.");
     setMessages([...next,{role:"assistant",content:data.reply}]);
   }catch(e:any){
     setMessages([...next,{role:"assistant",content:"Não consegui falar com a IA agora. Confere a configuração do servidor e tenta de novo. Sem drama — mas configura essa porra direito. 😤"}]);
     setNotice(e.message||"Falha de conexão");
   }finally{setBusy(false);}
 }
 function speak(text:string){
   if(!("speechSynthesis" in window)){setNotice("Seu navegador não oferece leitura em voz alta.");return;}
   window.speechSynthesis.cancel();
   const u=new SpeechSynthesisUtterance(text);u.lang="en-US";u.rate=.92;window.speechSynthesis.speak(u);
 }
 function listen(){
   const w=window as any; const SR=w.SpeechRecognition||w.webkitSpeechRecognition;
   if(!SR){setNotice("Reconhecimento de voz não disponível neste navegador. Tente Chrome ou Edge.");return;}
   const rec=new SR();rec.lang="en-US";rec.interimResults=false;
   rec.onresult=(e:any)=>setInput(e.results[0][0].transcript);
   rec.onerror=()=>setNotice("Não consegui captar sua voz. Tente novamente.");
   rec.start();setNotice("Estou ouvindo… fala em inglês.");
 }
 return <main className="shell">
   <header className="top"><a className="brand" href="#"><span className="brandmark">!</span> SEM<span>PACIÊNCIA</span></a><div className="topright"><span className="live"><i/> TUTORA ONLINE</span><a href="#como-funciona">COMO FUNCIONA</a></div></header>
   <section className="hero">
    <div className="eyebrow"><span/> INGLÊS SEM DESCULPINHA</div>
    <h1>DESTRAVA ESSE<br/><em>INGLÊS.</em></h1>
    <p className="sub">Uma professora de IA. Zero enrolação. Errou? Ela corrige. Travou? Ela cobra. <b>Mas você aprende.</b></p>
    <div className="stats"><div><b>01</b><small>FALE TODO DIA</small></div><div><b>02</b><small>ERRE SEM MEDO</small></div><div><b>03</b><small>EVOLUA DE VERDADE</small></div></div>
   </section>
   <section className="workspace">
    <aside className="side">
      <div className="tutor"><div className="avatar">😤</div><div><b>PROFª SEM PACIÊNCIA</b><small>Direta. Sarcástica. Do seu lado.</small></div><span className="online"/></div>
      <label>NÍVEL ATUAL</label><select value={level} onChange={e=>setLevel(e.target.value)}><option>A1 — começando</option><option>A2 — básico</option><option>B1 — intermediário</option><option>B2 — independente</option><option>C1 — avançado</option></select>
      <label>O QUE VAMOS TREINAR?</label><div className="modes">{["Conversação","Gramática","Vocabulário","Entrevista"].map(x=><button className={mode===x?"selected":""} onClick={()=>setMode(x)} key={x}>{x}</button>)}</div>
      <div className="sidequote">“Não precisa falar perfeito. Precisa abrir a boca e praticar.”<b>— A PROFESSORA</b></div>
      <div className="disclaimer">A conversa é uma ferramenta de estudo. Revise informações importantes e não compartilhe dados pessoais.</div>
    </aside>
    <section className="chat">
      <div className="chathead"><div><span className="tinyred">●</span> SUA AULA DE HOJE <small> · {mode.toUpperCase()}</small></div><span className="secure">● SESSÃO DE PRÁTICA</span></div>
      <div className="messages">{messages.map((m,i)=><div className={"msg "+m.role} key={i}><div className="who">{m.role==="assistant"?"PROFª SEM PACIÊNCIA":"VOCÊ"}</div><div className="bubble">{m.content}</div>{m.role==="assistant"&&<button className="listen" onClick={()=>speak(m.content)}>▶ OUVIR EM INGLÊS</button>}</div>)}{busy&&<div className="typing">A professora está pensando<span>...</span></div>}<div ref={end}/></div>
      <div className="composer"><button className="mic" onClick={listen} title="Falar">🎙</button><input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Escreva sua resposta em inglês..." disabled={busy}/><button className="send" onClick={()=>send()} disabled={busy||!input.trim()}>MANDAR ↗</button></div>
      <div className="hint">DICA: TENTE RESPONDER EM INGLÊS. ELA VAI TE AJUDAR A CORRIGIR.</div>
      {notice&&<p className="notice">{notice}</p>}
    </section>
   </section>
   <section className="below" id="como-funciona"><div><span className="eyebrow">SEM PAPO FURADO</span><h2>ERROU? ÓTIMO.<br/><em>AGORA APRENDE.</em></h2></div><div className="steps"><article><b>01 / FALE</b><p>Converse sobre situações reais: escola, viagens, jogos, música e muito mais.</p></article><article><b>02 / RECEBA A CORREÇÃO</b><p>A tutora explica o erro, mostra a forma natural e pede para você tentar de novo.</p></article><article><b>03 / REPITA E EVOLUA</b><p>Pratique no seu nível e acompanhe seu desenvolvimento aula após aula.</p></article></div></section>
   <footer>SEM PACIÊNCIA © 2026 <span>FEITO PRA DESTRAVAR SEU INGLÊS.</span></footer>
 </main>
}