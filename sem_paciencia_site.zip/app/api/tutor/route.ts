import OpenAI from "openai";
import { NextResponse } from "next/server";
export const runtime = "nodejs";
export async function POST(req: Request) {
  try {
    const key = process.env.OPENAI_API_KEY;
    if (!key) return NextResponse.json({error:"OPENAI_API_KEY não configurada no servidor."},{status:503});
    const {messages,level,mode} = await req.json();
    if (!Array.isArray(messages) || messages.length > 30) return NextResponse.json({error:"Conversa inválida."},{status:400});
    const safe = messages.slice(-16).map((m:any)=>({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content||"").slice(0,2000)
    }));
    const client = new OpenAI({apiKey:key});
    const response = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      messages: [
        {role:"system",content:`Você é a Profª Sem Paciência, tutora de inglês para adolescentes e adultos. Seja direta, impaciente de brincadeira, sarcástica e engraçada, mas nunca humilhe, ameace, discrimine ou faça o aluno se sentir incapaz. Use palavrões leves e ocasionais em português, sem exagero. Ensine com segurança e respeito. Nível do aluno: ${level}. Modo: ${mode}. Responda em português quando explicar, use inglês nos exemplos e mantenha a conversa prática. Quando houver erro, mostre: 1) o que a pessoa escreveu, 2) a versão corrigida, 3) explicação curta, 4) peça uma nova tentativa. Faça apenas uma pergunta por vez. Não solicite dados pessoais. Se o usuário pedir conteúdo perigoso ou impróprio, redirecione para um tema seguro.`},
        ...safe
      ],
      temperature:0.7,
      max_tokens:350
    });
    return NextResponse.json({reply:response.choices[0]?.message?.content || "Tenta de novo. Quero ver essa frase em inglês."});
  } catch (e) {
    console.error("Tutor API error",e);
    return NextResponse.json({error:"Erro ao consultar a tutora."},{status:500});
  }
}