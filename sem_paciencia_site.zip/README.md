# SEM PACIÊNCIA — plataforma de prática de inglês

Projeto inicial em Next.js com:
- Interface responsiva em preto/vermelho.
- Chat conectado à API OpenAI pelo servidor (a chave não vai para o navegador).
- Tutora com personalidade direta e sarcástica, sem humilhar o aluno.
- Seletor de nível e modalidade.
- Leitura de mensagens em voz alta (Speech Synthesis do navegador).
- Entrada por voz quando o navegador oferece Web Speech API.

## Rodar localmente
1. Instale Node.js 20 ou superior.
2. Na pasta do projeto, execute `npm install`.
3. Copie `.env.example` para `.env.local`.
4. Preencha `OPENAI_API_KEY` no arquivo `.env.local`.
5. Execute `npm run dev` e abra `http://localhost:3000`.

## O que ainda precisa ser configurado para produção
- **Autenticação e banco:** o pacote Supabase já está incluído e as variáveis estão previstas, mas o fluxo de cadastro/login, tabelas, políticas RLS e persistência de progresso ainda precisam ser implementados.
- **Voz avançada:** o microfone usa reconhecimento de voz do navegador, que varia conforme dispositivo/navegador. Para conversação por voz em tempo real, integre uma API de áudio em tempo real no servidor.
- **Privacidade e segurança:** antes de publicar, adicione política de privacidade, termos, limites de uso, proteção contra abuso, monitoramento e controles adequados para usuários menores de idade.
- **Deploy:** publique em um serviço compatível com Next.js e configure as variáveis de ambiente no painel do provedor. Nunca coloque chaves secretas no código do navegador.

Este projeto é um starter funcional, não um serviço já hospedado nem um produto pronto para receber pagamentos ou dados reais.
